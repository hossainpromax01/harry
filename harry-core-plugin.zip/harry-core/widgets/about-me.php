<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_About_Me extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_about_me';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'About Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-handle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_about_style',
			[
				'label' => esc_html__( 'About Style', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
		$this->add_control(
			'harry_about_select',
			[
				'label' => esc_html__( 'About Style', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'style-01',
				'options' => [
					'style-01' => esc_html__( 'Style 01', 'harry' ),
					'style-02'  => esc_html__( 'Style 02', 'harry' ),
					'style-03' => esc_html__( 'Style 03', 'harry' ),
				],
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'harry_hero',
			[
				'label' => esc_html__( 'Harry About', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry_sub_title',
			[
				'label' => esc_html__( 'Harry Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Sub heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your Sub title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_details',
			[
				'label' => esc_html__( 'Harry Details', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'This is Harry details', 'harry' ),
				'placeholder' => esc_html__( 'Type your details here', 'harry' ),
			]
		);
		$this->end_controls_section();

		
		$this->start_controls_section(
			'harry_button',
			[
				'label' => esc_html__( 'Harry Button', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry_button_text',
			[
				'label' => esc_html__( 'Button Text', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Book A Call', 'harry' ),
				'placeholder' => esc_html__( 'Type your Button Text Here', 'harry' ),
			]
		);
		
		$this->add_control(
			'harry_button_url',
			[
				'label' => esc_html__( 'Button Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'harry_social',
			[
				'label' => esc_html__( 'Harry Social', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				'condition' => [
					'harry_about_select' => 'style-02',
				],
			]
		);

		$repeater = new \Elementor\Repeater();
		
		
		$repeater->add_control(
			'harry_social_text',
			[
				'label' => esc_html__( 'Social Text', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Book A Call', 'harry' ),
				'placeholder' => esc_html__( 'Type your Button Text Here', 'harry' ),
			]
		);
		
		
		$repeater->add_control(
			'icon_select',
			[
				'label' => esc_html__( 'Choose Icon', 'harry' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'default' => 'icon',
				'options' => [
					'icon' => esc_html__( 'Icon', 'harry' ),
					'svg'  => esc_html__( 'SVG', 'harry' ),
				],
				'selectors' => [
					'{{WRAPPER}} .your-class' => 'icon_select: {{VALUE}};',
				],
				'label_block' => true
			]
		);

		$repeater->add_control(
			'harry_social_icon',
			[
				'label' => esc_html__( 'Social', 'harry' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fas fa-smile',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
				'condition' => [
					'icon_select' => 'icon',
				],
			]
		);
		$repeater->add_control(
			'harry_social_button_url',
			[
				'label' => esc_html__( 'Social Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'harry_svg',
			[
				'label' => esc_html__( 'SVG', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'placeholder' => esc_html__( 'SVG Icon Here', 'harry' ),
				'condition' => [
					'icon_select' => 'svg',
				],
			]
		);
		$this->add_control(
			'harry_social_list',
			[
				'label' => esc_html__( 'Social List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'harry_social_text' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'harry_social_text' => esc_html__( 'Title #2', 'harry' ),
					],
				],
				'title_field' => '{{{ harry_social_text }}}',
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( ! empty( $settings['harry_button_url']['url'] ) ) {
			$this->add_link_attributes( 'harry_button_url_receive', $settings['harry_button_url'] );
			$this->add_render_attribute( 'harry_button_url_receive', 'class', 'tp-btn' );
			}
		
		?>
		 

		<?php if($settings['harry_about_select'] == 'style-01') : ?>
		 <section class="about__area about__space-145">
			<div class="about__inner-9 black-bg wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
			<div class="container">
				<div class="row justify-content-center">
				<div class="col-xxl-10 col-xl-10 col-lg-11 col-md-10">
					<div class="about__wrapper-9">
					<?php if(!empty($settings['harry_sub_title'])) : ?>
						<span class="about-subtitle"><?php echo esc_html($settings['harry_sub_title']); ?></span>
					<?php endif; ?>
					<?php if(!empty($settings['harry_title'])) : ?>
						<h3 class="about-title"><?php echo wp_kses_post(($settings['harry_title'])); ?></h3>
					<?php endif; ?>
					<?php if(!empty($settings['harry_details'])) : ?>
						<p><?php echo esc_html($settings['harry_details']); ?></p>
					<?php endif; ?>	
					<div class="about__btn-9">
						<a <?php echo $this->get_render_attribute_string( 'harry_button_url_receive' ); ?>> <?php echo esc_html($settings['harry_button_text']); ?></a>
					</div>
					</div>
				</div>
				</div>
			</div>
			</div>
         	</section>


		<?php elseif($settings['harry_about_select'] == 'style-02') : ?>
		<section class="about__me-info pb-90 pt-110">
			<div class="container">
			<div class="row">
				<div class="col-xl-4 col-lg-3">
				<?php if(!empty($settings['harry_sub_title'])) : ?>
					<span class="about__me-info-subtitle"><?php echo esc_html($settings['harry_sub_title']); ?></span>
				<?php endif; ?> 
				</div>
				<div class="col-xl-8 col-lg-9">
				<div class="about__me-info-content wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
					<?php if(!empty($settings['harry_title'])) : ?>
						<h4 class="about__me-info-title">
						<?php echo esc_html($settings['harry_title']); ?>
							<img src="<?php get_template_directory_uri(); ?>/assets/img/about/about-me-title-icon.png" alt="">
						</h4>
					<?php endif; ?>
					
					<?php if(!empty($settings['harry_details'])) : ?>
					<p><?php echo esc_html($settings['harry_details']); ?></p>

					<?php endif; ?>
					<div class="about__me-info-bottom d-sm-flex align-items-center mt-40">
					<div class="about__me-info-btn mr-30">
					<?php if(!empty($settings['harry_button_text'])) : ?>
						<a <?php echo $this->get_render_attribute_string( 'harry_button_url_receive' ); ?> target="_blank" class="tp-btn">
						<?php echo esc_html($settings['harry_button_text']);?>
						<svg width="14" height="14" viewBox="0 0 14 14" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M1 7H13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M7 1L13 7L7 13" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
						</a>
					<?php endif; ?>
					</div>

					<div class="about__me-info-social">
						<?php foreach($settings['harry_social_list'] as $item) : 
							// var_dump($item);
							?>
						
						<a href="<?php echo $item['harry_social_button_url']['url']; ?>">
						<!-- harry_button_social_text harry_social_button_url-->
						
						<?php if(!empty($item['icon_select'] == 'icon' )) : ?>
						<?php \Elementor\Icons_Manager::render_icon( $item['harry_social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						<?php else: ?>
							<?php echo esc_html($item['harry_svg']); ?>
						<?php endif; ?>
						
						<?php echo esc_html($item['harry_social_text']); ?></a>
						<?php endforeach; ?>
					</div>
					</div>
				</div>
				</div>
			</div>
			</div>
            </section>


		<?php else: ?>
			<h2>There is coming soon</h2>
		<?php endif; ?>
		<?php		
	}

	
}
$widgets_manager->register( new Harry_About_Me() );