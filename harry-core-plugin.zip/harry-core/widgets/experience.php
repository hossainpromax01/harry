<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Experience extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_experience_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Experience Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-external-link-square';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_experience_section',
			[
				'label' => esc_html__( 'Harry Project', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		
	
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'harry_experience_sub_title',
			[
				'label' => esc_html__( 'Harry Eperience Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_experience_title',
			[
				'label' => esc_html__( 'Harry Experience Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$repeater->add_control(
			'harry_experience_image',
			[
				'label' => esc_html__( 'Harry Experience Image', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$repeater->add_control(
			'harry-button-url',
			[
				'label' => esc_html__( 'Service Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'harry_experience_date',
			[
				'label' => esc_html__( 'Harry Experience Date', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
				'label_block' => true
			]
		);
		$this->add_control(
			'harry_experience_list',
			[
				'label' => esc_html__( 'Experience List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'harry_experience_title' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'harry_experience_title' => esc_html__( 'Title #2', 'harry' ),
					],
				],
				'title_field' => '{{{ harry_experience_title }}}',
			]
		);
		
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( ! empty( $settings['harry-button-url']['url'] ) ) {
			$this->add_link_attributes( 'harry-button-url-receive', $settings['harry-button-url'] );
			}
		
		?>

<div class="career__wrapper career__style-2 pl-60">
                        <!-- <h4 class="career__title">Experience</h4> -->
				<?php foreach (  $settings['harry_experience_list'] as $item ) : ?>
                        <div class="career__item transition-3 white-bg d-sm-flex align-items-center justify-content-between wow fadeInUp" data-wow-delay=".3s" data-wow-duration="1s">
                           <div class="career__info d-sm-flex align-items-center">
                              <div class="career__logo mr-20">
                                 <span>
                                    <img src="<?php echo $item['harry_experience_image']['url']; ?>" alt="">
                                 </span>
                              </div>
                              <div class="career__info-content">
                                 <h3 class="career__info-title"><?php echo esc_html($item['harry_experience_title']); ?></h3>
                                 <span class="career__info-designation"><?php echo esc_html($item['harry_experience_sub_title']); ?></span>
                              </div>
                           </div>
                           <div class="career__year text-sm-end">
                              <div class="career__btn">
                                 <a href="<?php echo $this->get_render_attribute_string( 'harry-button-url-receive' ); ?>" class="career-link-btn">
                                    <span>
                                       <svg width="23" height="23" viewBox="0 0 23 23" fill="none" xmlns="http://www.w3.org/2000/svg">
                                          <path d="M17.7392 15.2608L18.0502 5.05021L7.83967 5.36134" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                          <path d="M5.32384 17.7797L18.0518 5.05176" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                       </svg>                                                                               
                                    </span>                                       
                                 </a>
                              </div>
                              <div class="career__year-info">
                                 <p><?php echo esc_html($item['harry_experience_date']); ?></p>
                              </div>
                           </div>
                        </div>
				<?php endforeach; ?>
                     </div>
		<?php		
	}

	

}
$widgets_manager->register( new Harry_Experience() );