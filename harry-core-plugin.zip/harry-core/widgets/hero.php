<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Hero_Widget extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_hero_widget';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Hero Widget', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-posts-ticker';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry-hero',
			[
				'label' => esc_html__( 'Harry Hero', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry-sub-title',
			[
				'label' => esc_html__( 'Harry Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Sub heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your Sub title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry-title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry-hero-details',
			[
				'label' => esc_html__( 'Harry Details', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Harry details', 'harry' ),
				'placeholder' => esc_html__( 'Type your details here', 'harry' ),
			]
		);
		$this->end_controls_section();


		$this->start_controls_section(
			'harry-hero-button',
			[
				'label' => esc_html__( 'Harry Hero Button', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry-button-text',
			[
				'label' => esc_html__( 'Button Text', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Book A Call', 'harry' ),
				'placeholder' => esc_html__( 'Type your Button Text Here', 'harry' ),
			]
		);
		
		$this->add_control(
			'harry-button-url',
			[
				'label' => esc_html__( 'Button Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::URL,
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '#',
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
			]
		);
		$this->end_controls_section();

		

		$this->start_controls_section(
			'harry-hero-image',
			[
				'label' => esc_html__( 'Harry Hero Image', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'harry-hero-right-image',
			[
				'label' => esc_html__( 'Choose Image', 'harry' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		
		$this->end_controls_section();

		$this->start_controls_section(
			'harry-social-section',
			[
				'label' => esc_html__( 'Harry Social', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'harry-hero-icon',
			[
				'label' => esc_html__( 'Social', 'harry' ),
				'type' => \Elementor\Controls_Manager::ICON,
				'default' => [
					'value' => 'fas fa-smile',
					'library' => 'fa-solid',
				],
				'recommended' => [
					'fa-solid' => [
						'circle',
						'dot-circle',
						'square-full',
					],
					'fa-regular' => [
						'circle',
						'dot-circle',
						'square-full',
					],
				],
			]
		);
		$repeater->add_control(
			'icon_url',
			[
				'label' => esc_html__( 'Url', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( '#' , 'harry' ),
				'label_block' => true,
			]
		);


		// $repeater->add_control(
		// 	'list_color',
		// 	[
		// 		'label' => esc_html__( 'Color', 'harry' ),
		// 		'type' => \Elementor\Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} {{CURRENT_ITEM}}' => 'color: {{VALUE}}'
		// 		],
		// 	]
		// );

		$this->add_control(
			'harry-social-list',
			[
				'label' => esc_html__( 'Repeater List', 'harry' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title #1', 'harry' ),
					],
					[
						'list_title' => esc_html__( 'Title #2', 'harry' ),
					],
				],
			]
		);
		
		
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		if ( ! empty( $settings['harry-button-url']['url'] ) ) {
			$this->add_link_attributes( 'harry-button-url-receive', $settings['harry-button-url'] );
			$this->add_render_attribute( 'harry-button-url-receive', 'class', 'tp-btn-5 tp-link-btn-3' );
			$this->add_render_attribute( 'harry-button-url-receive', 'title', 'btn11' );
			$this->add_render_attribute( 'harry-button-url-receive', 'id', 'new-id' );
			}
		?>
		 <!-- slider area start -->
		 <section class="slider__area pt-40 p-relative fix">
            <div class="slider__item-9">
               <div class="container">
                  <div class="row align-items-end">
                     <div class="col-xl-7 col-lg-6 col-md-7">
                        <div class="slider__content-9">
				   <?php if(!empty($settings['harry-sub-title'])) : ?>
                           	<span class="slider__title-pre-9"><?php echo esc_html($settings['harry-sub-title']); ?></span>
				   <?php endif; ?>
				   <?php if(!empty($settings['harry-title'])) : ?>
                           	<h3 class="slider__title-9"><?php echo wp_kses_post(($settings['harry-title'])); ?></h3>
				   <?php endif; ?>
				   <?php if(!empty($settings['harry-hero-details'])) : ?>
                           	<p><?php echo esc_html($settings['harry-hero-details']); ?></p>
				   <?php endif; ?>

                           <div class="slider__btn-9 mb-85">
					
                              <a <?php echo $this->get_render_attribute_string( 'harry-button-url-receive' ); ?> > 
					<?php if(!empty($settings['harry-hero-details'])) : ?>
                                 <?php echo esc_html($settings['harry-button-text']); ?>
					<?php endif; ?>
                                 <span>
                                    <i class="fa-regular fa-arrow-right"></i>
                                 </span>
                              </a>
                           </div>

                           <div class="slider__social-9 d-flex flex-wrap align-items-center social-banner">
                              <span>Check out my:</span>
                              <ul>
					<?php foreach (  $settings['harry-social-list'] as $item ) : ?>
                               <li>
                                    <a href="<?php echo $item['icon_url']; ?>">
							<?php \Elementor\Icons_Manager::render_icon( $item['harry-hero-icon'], [ 'aria-hidden' => 'true' ] ); ?>                                      
                                    </a>
                                 </li>
                                <?php endforeach; ?>
                              </ul>
                           </div>
                        </div>
                     </div>
                     <div class="col-xl-5 col-lg-6 col-md-5 order-first order-md-last">
                        <div class="slider__thumb-9 p-relative scene">
                           <div class="slider__shape">
                              <div class="slider__shape-20">
                                 <img class="layer" data-depth=".2" src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/9/slider-shape-1.png" alt="">
                              </div>
                              <div class="slider__shape-21">
                                 <img class="layer" data-depth=".3" src="<?php echo get_template_directory_uri(); ?>/assets/img/slider/9/slider-shape-2.png" alt="">
                              </div>
                           </div>
                           	<img class="slider__thumb-9-main" src="<?php echo $settings['harry-hero-right-image']['url']; ?>" alt="">
				   
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>
		<?php		
	}

	
}
$widgets_manager->register( new Harry_Hero_Widget() );