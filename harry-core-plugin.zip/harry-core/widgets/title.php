<?php
namespace HarryCoreModule\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Elementor Hello World
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class Harry_Title extends Widget_Base {

	/**
	 * Retrieve the widget name.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'harry_title';
	}

	/**
	 * Retrieve the widget title.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Harry Title', 'harry-core' );
	}

	/**
	 * Retrieve the widget icon.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-handle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * Note that currently Elementor supports only one category.
	 * When multiple categories passed, Elementor uses the first one.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'harry-custom-category' ];
	}

	/**
	 * Retrieve the list of scripts the widget depended on.
	 *
	 * Used to set scripts dependencies required to run the widget.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 *
	 * @return array Widget scripts dependencies.
	 */
	public function get_script_depends() {
		return [ 'harry-core' ];
	}

	/**
	 * Register the widget controls.
	 *
	 * Adds different input fields to allow the user to change and customize the widget settings.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function register_controls() {
		$this->start_controls_section(
			'harry_title_section',
			[
				'label' => esc_html__( 'Harry About', 'harry' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'active_switch',
			[
				'label' => esc_html__( 'Active Item', 'harry' ),
				'type' => \Elementor\Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'harry' ),
				'label_off' => esc_html__( 'Hide', 'harry' ),
				'return_value' => 'yes',
				'default' => '',
			]
		);
		$this->add_control(
			'harry_sub_title',
			[
				'label' => esc_html__( 'Harry Sub Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is Sub heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your Sub title here', 'harry' ),
			]
		);
		$this->add_control(
			'harry_title',
			[
				'label' => esc_html__( 'Harry Title', 'harry' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'This is heading', 'harry' ),
				'placeholder' => esc_html__( 'Type your title here', 'harry' ),
			]
		);
		$this->end_controls_section();
	}

	/**
	 * Render the widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 *
	 * @access protected
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		$active_switch = ($settings['active_switch']) ? "is-center" : '';
		?>
			<div class="section__title-wrapper-9 mb-65 <?php echo esc_html($active_switch); ?>">
			   <?php if(!empty($settings['harry_sub_title'])) : ?>
                        <span class="section__title-pre-9"><?php echo esc_html($settings['harry_sub_title']); ?></span>
			   <?php endif; ?>
			   <?php if(!empty($settings['harry_title'])) : ?>
                        <h3 class="section__title-9"><?php echo esc_html($settings['harry_title']); ?></h3>
			   <?php endif; ?>
                   </div>

		<?php		
	}

	
}
$widgets_manager->register( new Harry_Title() );